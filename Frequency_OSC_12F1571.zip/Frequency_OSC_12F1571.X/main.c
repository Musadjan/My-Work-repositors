/**
  Generated Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This is the main file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  Description:
    This header file provides implementations for driver APIs for all modules selected in the GUI.
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.65.2
        Device            :  PIC12F1571
        Driver Version    :  2.00
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/

#include "mcc_generated_files/mcc.h"
#include <stdio.h>

/*
                         Main application
 */
void main(void)
{
    // initialize the device
    SYSTEM_Initialize();

    // When using interrupts, you need to set the Global and Peripheral Interrupt Enable bits
    // Use the following macros to:

    // Enable the Global Interrupts
    INTERRUPT_GlobalInterruptEnable();
    
    uint8_t hf_mode, lf_mode;

    uint16_t adc_value, adc_old_value = 0;
    int16_t adc_diff = 0;
    uint16_t pwm_pr, pwm_pr_old, pwm_dc;
 

    uint8_t tmp_reg;
    uint8_t uart_buffer[20];
    
    
    const uint16_t pwm_map[] = {20408,10204, 5102, 3401, 2551, 2041, 1701, 1458, 1276, 1134, 1020,
        928, 850, 785, 729, 680, 638, 600, 567, 537, 510, 486, 464, 444, 425, 408, 392, 378, 364, 352,
        340, 329, 319, 309, 300, 292, 283, 276, 269, 262, 255, 249, 243, 237, 232, 227, 222, 217, 213,
        208, 204, 200, 196, 193, 189, 186, 182, 179, 176, 173, 170, 167, 165, 162, 159, 157, 155, 152,
        150, 148, 146, 144, 142, 140, 138, 136, 134, 133, 131, 129, 128, 126, 124, 123, 121, 120, 119,
        117, 116, 115, 113, 112, 111, 110, 109, 107, 106, 105, 104, 103, 102, 101, 100, 99, 98, 97, 96,
        95, 94, 94, 93, 92, 91, 90, 90, 89, 88, 87, 86, 86, 85, 84, 84, 83, 82, 82, 81, 80, 80, 79, 78,
        78, 77, 77, 76, 76, 75, 74, 74, 73, 73, 72, 72, 71, 71, 70, 70, 69, 69, 68, 68, 68, 67, 67, 66,
        66, 65, 65, 65, 64, 64, 63, 63, 63, 62, 62, 61, 61, 61, 60, 60, 60, 59, 59, 59, 58, 58, 58, 57,
        57, 57, 56, 56, 56, 55, 55, 55, 55, 54, 54, 54, 53, 53, 53, 53, 52, 52, 52, 52, 51, 51, 51, 51,
        50, 50, 50, 50, 49, 49, 49, 49, 48, 48, 48, 48, 47, 47, 47, 47, 47, 46, 46, 46, 46, 46, 45, 45,
        45, 45, 45, 44, 44, 44, 44, 44, 43, 43, 43, 43, 43, 43, 42, 42, 42, 42, 42, 41, 41, 41, 40, 40,
        40, 38, 36, 34, 32, 30};

    uint16_t freq;
    
    
    hf_mode = RA4;
    
//    __delay_ms(500);
  
    while(true)
    {
        __delay_ms(200);
        adc_value = ADC1_GetConversion(channel_AN2);
//        if (!hf_mode) {
//            if (pwm_pr > 61) {
//                freq = 1000/pwm_pr; 
//            }
//        }
       
        if (RA4 != hf_mode) {
            hf_mode = RA4;
            if (hf_mode) {
                tmp_reg = PWM1CON;
                PWM1CON = 0x04; // Disables PWM to be able to update registers
                PWM1CLKCON = 0x60; // 64 pre-scaler
                PWM1PRL = 0x23;
                PWM1PRH = 0xf4;
                PWM1DCL = 0xd4;
                PWM1DCH = 0x30;
                PWM1CON = tmp_reg; // Enables PWM
            }
        }
         
        if (!hf_mode) {
            // Noise cancellation
            adc_diff = adc_value - adc_old_value;
            if (-60 < adc_diff && 60 > adc_diff) {
                // Do nothing
            } else {
                pwm_pr = pwm_map[adc_value >> 8];
                adc_old_value = adc_value;
            }

             //Only update if diff
            //if (pwm_pr != pwm_pr_old) {
            if (!RA4) {
                pwm_pr_old = pwm_pr;
                tmp_reg = PWM1CON;
                PWM1CON = 0x04; // Disables PWM to be able to update registers
                PWM1CLKCON = 0; // No pre-scaler

                PWM1PRL = pwm_pr & 0x00ff; // Sets PWM max counter
                PWM1PRH = pwm_pr >> 8;

                pwm_dc = pwm_pr / 2; // Duty cycle = 50% */
                PWM1DCL = pwm_dc & 0x00ff;
                PWM1DCH = pwm_dc >> 8;

                PWM1CON = tmp_reg; // Enables PWM
                __delay_ms(10);
            }
        }
    }
    
    }
    

/**
 End of File
*/